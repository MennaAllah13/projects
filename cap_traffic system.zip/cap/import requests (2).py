import requests as req # type: ignore

url = "http://127.0.0.1:5000/predict"
data = {"mq_value": 50}  # استبدلي بالرقم الذي تريدين

response = requests.post(url, json=data)
print(response.status_code)
print(response.json())