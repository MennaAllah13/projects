#include <WiFi.h>
#include <HTTPClient.h>

const char* ssid = "Rana";
const char* password = "RANA2008";

// استخدمي الـ IP الصحيح من ipconfig
const char* serverName = "http://10.185.137.215:8000/predict";

const int mq135Pin = 34;

void setup() {
  Serial.begin(115200);
  delay(1000);
  
  Serial.println("🚀 Starting ESP32...");
  
  // توصيل الواي فاي
  WiFi.begin(ssid, password);
  Serial.print("📡 Connecting to WiFi");
  
  unsigned long startTime = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - startTime < 15000) {
    delay(500);
    Serial.print(".");
  }
  
  if (WiFi.status() == WL_CONNECTED) {
    Serial.println();
    Serial.println("✅ WiFi connected!");
    Serial.print("📱 ESP32 IP: ");
    Serial.println(WiFi.localIP());
    Serial.print("🎯 Server IP: ");
    Serial.println("10.185.137.215:8000");
    
    // اختيار السيرڤر أول مرة
    testServerConnection();
  } else {
    Serial.println();
    Serial.println("❌ WiFi connection failed!");
  }
}

void loop() {
  if (WiFi.status() != WL_CONNECTED) {
    Serial.println("❌ WiFi disconnected! Reconnecting...");
    WiFi.begin(ssid, password);
    delay(5000);
    return;
  }
  
  // قراءة الحساس
  int rawValue = analogRead(mq135Pin);
  Serial.print("🔢 MQ135 Raw Value: ");
  Serial.println(rawValue);
  
  // إذا القيمة 0، ممكن البن مش متصل صح
  if (rawValue == 0) {
    Serial.println("⚠️  Warning: Sensor reading is 0 - check wiring!");
  }
  
  // تحويل إلى CO2 (قيمة تقريبية)
  int co2Value = map(rawValue, 0, 4095, 300, 1200);
  Serial.print("🌫️ CO2 Estimate: ");
  Serial.print(co2Value);
  Serial.println(" ppm");
  
  // إرسال البيانات
  sendToServer(co2Value);
  
  delay(10000); // انتظر 10 ثواني
}

void testServerConnection() {
  Serial.println("🧪 Testing server connection...");
  
  HTTPClient http;
  http.begin("http://10.185.137.215:8000/health");
  http.setTimeout(5000);
  
  int httpCode = http.GET();
  
  if (httpCode == 200) {
    String response = http.getString();
    Serial.println("✅ Server is alive! Response: " + response);
  } else {
    Serial.print("❌ Server test failed! HTTP Code: ");
    Serial.println(httpCode);
    
    if (httpCode == -1) {
      Serial.println("💡 Tips:");
      Serial.println("1. Make sure Flask server is running");
      Serial.println("2. Check firewall settings on computer");
      Serial.println("3. Verify both devices on same WiFi network");
    }
  }
  
  http.end();
}

void sendToServer(int co2) {
  Serial.println("📤 Attempting to send data to server...");
  
  HTTPClient http;
  http.setTimeout(10000);
  http.begin(serverName);
  http.addHeader("Content-Type", "application/json");
  
  String jsonData = "{\"CO2\": " + String(co2) + "}";
  Serial.println("📦 JSON Data: " + jsonData);
  
  Serial.print("🔄 Sending POST request...");
  int httpResponseCode = http.POST(jsonData);
  Serial.println(" Done!");
  
  Serial.print("📨 HTTP Response Code: ");
  Serial.println(httpResponseCode);
  
  if (httpResponseCode > 0) {
    String response = http.getString();
    Serial.println("📥 Server Response: " + response);
    
    if (httpResponseCode == 200) {
      Serial.println("🎉 Data sent successfully!");
      
      // استخراج التنبؤ من الرد
      int startIndex = response.indexOf("\"prediction\":\"") + 14;
      int endIndex = response.indexOf("\"", startIndex);
      String prediction = response.substring(startIndex, endIndex);
      
      Serial.print("🎯 Air Quality: ");
      Serial.println(prediction);
      
    } else {
      Serial.println("⚠️ Server returned error");
    }
  } else {
    Serial.print("❌ Failed to send data. Error: ");
    
    switch(httpResponseCode) {
      case -1: Serial.println("Connection refused"); break;
      case -2: Serial.println("Send header failed"); break;
      case -3: Serial.println("Send payload failed"); break;
      case -4: Serial.println("Not connected"); break;
      case -5: Serial.println("Connection lost"); break;
      default: Serial.println("Unknown error"); break;
    }
  }
  
  http.end();
  Serial.println("----------------------------------------");
}