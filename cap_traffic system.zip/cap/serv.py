import weka.core.jvm as jvm
from weka.classifiers import Classifier
from weka.core.dataset import Attribute, Instance, Instances
from flask import Flask, request, jsonify

# Start JVM
print("Starting JVM...")
jvm.start()
print("JVM started successfully.")

# Load the trained Weka model
print("Loading Weka model...")
model = Classifier(jobject=Classifier.deserialize("mq_model.model"))
print("Model loaded successfully.")

# Flask server
app = Flask(__name__)

@app.route("/predict", methods=["POST"])
def predict():
    data = request.json
    print(f"Received data: {data}")  # <-- طباعة البيانات اللي وصلته

    mq_value = float(data["mq_value"])

    # Create instance dynamically
    attr = [Attribute("mq_value"), Attribute("class", ["safe","moderate","heavy"])]
    dataset = Instances(name="TestInstances", attributes=attr, class_index=1)
    inst = Instance([mq_value, None])
    dataset.add_instance(inst)

    prediction_idx = model.classify_instance(dataset[0])
    prediction_label = dataset.class_attribute.value(int(prediction_idx))

    print(f"Prediction result: {prediction_label}")  # <-- طباعة النتيجة
    return jsonify({"prediction": prediction_label})

if __name__ == "__main__":
    print("Server running at http://0.0.0.0:5000")
    app.run(host="0.0.0.0", port=5000)