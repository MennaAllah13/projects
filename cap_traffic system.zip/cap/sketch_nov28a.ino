#include <esp_now.h>
#include <WiFi.h>
#include <ESP32Servo.h>
#include <LiquidCrystal_I2C.h>
#include <HTTPClient.h>

// إعدادات الواي فاي
const char* ssid = "Menna";
const char* password = "menna2677";
const char* serverURL = "http://10.29.92.215:8000/predict";

// إعدادات الأجهزة
int counter = 0;
LiquidCrystal_I2C lcd(0x27, 16, 2); 
Servo myServo;
int servoPin = 13;
const int MQ135_PIN = 34;

// هيكل بيانات ESP-NOW
typedef struct struct_message {
  char message[32];
} struct_message;

bool connected = false;

// متغيرات التوقيت
unsigned long previousMQ135Time = 0;
const unsigned long MQ135Interval = 10000; // 10 ثواني
unsigned long lastLCDUpdate = 0;
const unsigned long LCDInterval = 2000; // تحديث LCD كل 2 ثانية

void setup() {
  Serial.begin(115200);
  delay(1000);
  
  Serial.println("🚀 بدء تشغيل النظام المتكامل...");
  
  // تهيئة LCD
  lcd.init();
  lcd.backlight();
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("System Starting");
  delay(1000);
  
  // تهيئة السيرفو
  myServo.attach(servoPin);
  myServo.write(0); // وضع البداية
  Serial.println("✅ السيرفو جاهز");
  
  // تهيئة حساس MQ135
  pinMode(MQ135_PIN, INPUT);
  Serial.println("✅ حساس MQ135 جاهز");
  
  // تهيئة WiFi
  WiFi.mode(WIFI_STA);
  setupWiFi();
  
  // تهيئة ESP-NOW
  if (esp_now_init() != ESP_OK) {
    Serial.println("❌ خطأ في تهيئة ESP-NOW");
    lcd.clear();
    lcd.print("ESP-NOW Error");
    delay(2000);
  } else {
    esp_now_register_recv_cb(OnDataRecv);
    Serial.println("✅ ESP-NOW جاهز");
  }
  
  // العرض النهائي
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("System Ready");
  lcd.setCursor(0, 1);
  lcd.print("WiFi & ESP-NOW");
  
  Serial.println("🎯 النظام المتكامل جاهز للعمل!");
  delay(2000);
}

void setupWiFi() {
  Serial.print("📡 جاري الاتصال بـ ");
  Serial.println(ssid);
  
  lcd.clear();
  lcd.print("Connecting WiFi");
  lcd.setCursor(0, 1);
  lcd.print(ssid);
  
  WiFi.begin(ssid, password);
  
  int attempts = 0;
  while (WiFi.status() != WL_CONNECTED && attempts < 15) {
    delay(1000);
    Serial.print(".");
    attempts++;
  }
  
  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("\n✅ متصل بالواي فاي!");
    Serial.print("📶 IP: ");
    Serial.println(WiFi.localIP());
  } else {
    Serial.println("\n⚠️  فشل الاتصال بالواي فاي - العمل بدون إنترنت");
  }
}

void OnDataRecv(const esp_now_recv_info_t *info, const uint8_t *incomingData, int len) {
  Serial.println("📡 استقبال بيانات من ESP-NOW...");
  
  struct_message myMessage;
  memcpy(&myMessage, incomingData, sizeof(myMessage));
  
  Serial.print("📨 الرسالة: "); 
  Serial.println(myMessage.message);
  
  // تحريك السيرفو
  moveServo();
  
  // تحديث LCD
  updateLCD("Ambulance Alert", "Message Received");
  
  counter++;
  Serial.println("✅ تم معالجة بيانات ESP-NOW");
}

void moveServo() {
  Serial.println("🔄 تحريك السيرفو...");
  
  // تحريك من 0 إلى 180 درجة
  for (int pos = 0; pos <= 180; pos += 2) {
    myServo.write(pos);
    delay(10);
  }
  delay(500);
  
  // العودة إلى 0 درجة
  for (int pos = 180; pos >= 0; pos -= 2) {
    myServo.write(pos);
    delay(10);
  }
  
  Serial.println("✅ اكتمل تحريك السيرفو");
}

void updateLCD(String line1, String line2) {
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print(line1);
  lcd.setCursor(0, 1);
  lcd.print(line2);
}

void readAndSendSensorData() {
  Serial.println("🔍 قراءة بيانات الحساس...");
  
  int mq135Value = analogRead(MQ135_PIN);
  int co2Estimate = map(mq135Value, 0, 4095, 300, 5000);
  
  Serial.print("🔢 قيمة الحساس: ");
  Serial.print(mq135Value);
  Serial.print(" | تقدير CO2: ");
  Serial.print(co2Estimate);
  Serial.println(" ppm");
  
  // تصنيف محلي
  String prediction = classifyCO2(co2Estimate);
  Serial.print("🎯 التوقع: ");
  Serial.println(prediction);
  
  // عرض على LCD لمدة 3 ثواني
  updateLCD("CO2: " + String(co2Estimate), "Level: " + prediction);
  
  // إرسال للخادم
  sendToServer(co2Estimate);
  
  delay(3000); // عرض القراءة لمدة 3 ثواني
}

String classifyCO2(int co2Value) {
  if (co2Value < 600) return "Safe";
  else if (co2Value < 900) return "Moderate";
  else return "Heavy";
}

void sendToServer(int co2Value) {
  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("📤 إرسال بيانات للخادم...");
    
    HTTPClient http;
    http.begin(serverURL);
    http.addHeader("Content-Type", "application/json");
    http.setTimeout(10000);
    
    String jsonData = "{\"CO2\":" + String(co2Value) + "}";
    Serial.println("📦 البيانات: " + jsonData);
    
    int httpResponseCode = http.POST(jsonData);
    
    if (httpResponseCode > 0) {
      Serial.print("✅ تم الإرسال - رمز الاستجابة: ");
      Serial.println(httpResponseCode);
      String response = http.getString();
      Serial.println("📨 رد الخادم: " + response);
    } else {
      Serial.print("❌ فشل الإرسال - الخطأ: ");
      Serial.println(httpResponseCode);
    }
    
    http.end();
  } else {
    Serial.println("⚠️  غير متصل بالإنترنت - تخطي الإرسال");
  }
}

void updateNormalDisplay() {
  unsigned long currentTime = millis();
  if (currentTime - lastLCDUpdate >= LCDInterval) {
    lastLCDUpdate = currentTime;
    
    lcd.clear();
    lcd.setCursor(0, 0);
    lcd.print("System Running");
    lcd.setCursor(0, 1);
    lcd.print("Count:");
    lcd.print(counter);
    lcd.print(" CO2:ON");
  }
}

void loop() {
  // قراءة حساس MQ135 كل 10 ثواني
  unsigned long currentTime = millis();
  if (currentTime - previousMQ135Time >= MQ135Interval) {
    previousMQ135Time = currentTime;
    readAndSendSensorData();
  }
  
  // تحديث العرض العادي على LCD
  updateNormalDisplay();
  
  delay(100); // تأخير بسيط لتجنب إرهاق المعالج
}

// دالة للتأكد من عمل السيرفو والLCD
void testHardware() {
  Serial.println("🔧 اختبار الأجهزة...");
  
  // اختبار LCD
  lcd.clear();
  lcd.print("Testing LCD");
  delay(1000);
  
  // اختبار السيرفو
  lcd.clear();
  lcd.print("Testing Servo");
  myServo.write(90);
  delay(1000);
  myServo.write(0);
  delay(1000);
  
  lcd.clear();
  lcd.print("Test Complete");
  Serial.println("✅ اختبار الأجهزة اكتمل");
}