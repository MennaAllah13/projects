from flask import Flask, request, jsonify
import weka.core.jvm as jvm
from weka.classifiers import Classifier
from weka.core.dataset import Attribute, Instances, Instance
import traceback
import sys

app = Flask(__name__)

# متغيرات عالمية
model = None
jvm_started = False

def initialize_weka():
    """تهيئة JVM وتحميل النموذج"""
    global model, jvm_started
    
    try:
        if not jvm_started:
            print("🚀 Starting JVM...")
            jvm.start(packages=True, max_heap_size="512m")
            jvm_started = True
            print("✅ JVM started successfully")
        
        print("📦 Loading Weka model...")
        # الطريقة الصحيحة لتحميل النموذج
        model = Classifier.deserialize(r"C:\cap\WEKA MQ.model")
        
        # إذا كان النموذج عبارة عن tuple، نأخذ العنصر الأول فقط
        if isinstance(model, tuple):
            model = model[0]
            print("🔧 Model was tuple, extracted first element")
            
        print("✅ Model loaded successfully")
        print(f"📊 Model type: {type(model)}")
        
        return True
        
    except Exception as e:
        print(f"❌ Initialization error: {e}")
        traceback.print_exc()
        return False

# تهيئة Weka عند بدء التشغيل
if not initialize_weka():
    print("⚠️ Failed to initialize Weka, but server will start anyway")

@app.route('/')
def home():
    status = "✅ Ready" if model else "❌ Model not loaded"
    return f"""
    <html>
        <head>
            <title>CO2 Prediction API</title>
            <style>
                body {{ font-family: Arial, sans-serif; margin: 40px; }}
                .status {{ padding: 10px; margin: 10px 0; border-radius: 5px; }}
                .ready {{ background: #d4edda; color: #155724; }}
                .error {{ background: #f8d7da; color: #721c24; }}
                code {{ background: #f4f4f4; padding: 2px 5px; border-radius: 3px; }}
            </style>
        </head>
        <body>
            <h1>CO2 Prediction API</h1>
            <div class="status {'ready' if model else 'error'}">
                Status: {status}
            </div>
            <p>استخدم endpoint <code>/predict</code> للتنبؤ</p>
            <p>استخدم endpoint <code>/health</code> للتحقق من الحالة</p>
        </body>
    </html>
    """

@app.route('/health')
def health_check():
    """Endpoint للتحقق من حالة الخادم والنموذج"""
    if model and jvm_started:
        return jsonify({
            "status": "healthy",
            "model_loaded": True,
            "jvm_running": True,
            "model_type": str(type(model))
        })
    else:
        return jsonify({
            "status": "degraded",
            "model_loaded": bool(model),
            "jvm_running": jvm_started
        }), 503

@app.route("/predict", methods=["POST"])
def predict():
    # إعادة تهيئة إذا كان النموذج غير محمل
    if not model:
        if not initialize_weka():
            return jsonify({"error": "Model not available"}), 503
    
    try:
        # جلب البيانات من JSON
        data = request.get_json(force=True)
        print("📥 Received data:", data)

        if "CO2" not in data:
            return jsonify({"error": "CO2 value is required"}), 400

        co2 = float(data.get("CO2", 0))
        print(f"🔢 CO2 value: {co2}")

        # التحقق من القيمة المدخلة
        if co2 <= 0:
            return jsonify({"error": "CO2 value must be positive"}), 400

        # تعريف الـ attributes - تأكد من المطابقة مع بيانات التدريب
        attr1 = Attribute.create_numeric("CO2")
        attr2 = Attribute.create_nominal("state", ["Safe", "Moderate", "Heavy"])
        attrs = [attr1, attr2]

        # إنشاء dataset
        ds = Instances.create_instances("CO2DATA", attrs, 0)
        ds.class_is_last()

        # إضافة instance
        inst = Instance.create_instance([co2, 0.0])  # القيمة الثانية مؤقتة
        ds.add_instance(inst)

        # عمل prediction
        pred_idx = int(model.classify_instance(ds.get_instance(0)))
        pred = ds.class_attribute.value(pred_idx)

        print(f"🎯 Prediction: {pred}")
        return jsonify({
            "prediction": pred,
            "input_co2": co2,
            "status": "success"
        })

    except ValueError as e:
        print(f"❌ Value error: {e}")
        return jsonify({"error": "Invalid CO2 value. Must be a number."}), 400
        
    except Exception as e:
        print(f"❌ Prediction error: {e}")
        traceback.print_exc()
        return jsonify({"error": f"Prediction failed: {str(e)}"}), 500

@app.errorhandler(404)
def not_found(error):
    return jsonify({"error": "Endpoint not found"}), 404

@app.errorhandler(500)
def internal_error(error):
    return jsonify({"error": "Internal server error"}), 500

def shutdown_handler():
    """إغلاق JVM بشكل آمن عند إيقاف الخادم"""
    if jvm_started:
        print("🛑 Shutting down JVM...")
        try:
            jvm.stop()
        except:
            pass

if __name__ == "__main__":
    try:
        print("🚀 Starting Flask server...")
        app.run(host="0.0.0.0", port=8000, debug=True)
    except KeyboardInterrupt:
        print("⏹️ Server stopped by user")
    except Exception as e:
        print(f"❌ Server error: {e}")
    finally:
        shutdown_handler()