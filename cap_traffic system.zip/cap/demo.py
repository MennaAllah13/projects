import pandas as pd
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

# قراءة البيانات
data = pd.read_csv("WEKA MQ.csv")

# نفترض إن العمود الأخير هو الـ label
X = data.iloc[:, :-1]  # كل الأعمدة ما عدا الأخير
y = data.iloc[:, -1]   # العمود الأخير

# تقسيم البيانات للتدريب والاختبار
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# تدريب Decision Tree (مكافئ لـ J48)
model = DecisionTreeClassifier()
model.fit(X_train, y_train)

# اختبار دقة الموديل
y_pred = model.predict(X_test)
print("Accuracy:", accuracy_score(y_test, y_pred))