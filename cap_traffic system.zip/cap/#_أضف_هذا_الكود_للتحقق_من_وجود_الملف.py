import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
import joblib
import os
from flask import Flask, request, jsonify

app = Flask(__name__)

# التصنيف اليدوي المضمون (يعمل بدون بيانات)
def classify_co2_manual(co2):
    """تصنيف مضمون 100% بناءً على العتبات المعروفة"""
    if co2 < 600:
        return "Safe"
    elif co2 < 900:
        return "Moderate"
    else:
        return "Heavy"

# محاولة تحميل البيانات إذا وجدت
def try_load_data():
    # جرب مسارات مختلفة للملف
    possible_paths = [
        'WEKA MQ.csv',
        'WEKA_MQ.csv', 
        'weka_mq.csv',
        'data.csv',
        '../WEKA MQ.csv',
        'C:/Users/Mega Store/Desktop/WEKA MQ.csv'
    ]
    
    for path in possible_paths:
        if os.path.exists(path):
            try:
                df = pd.read_csv(path)
                print(f"✅ تم تحميل البيانات من: {path}")
                return df
            except:
                continue
    
    print("❌ لم أجد ملف البيانات، باستخدام التصنيف اليدوي")
    return None

# تدريب النموذج إذا وجدت البيانات
def train_model_if_possible():
    df = try_load_data()
    
    if df is not None:
        try:
            X = df[['CO2']].values
            y = df['state'].values
            
            model = RandomForestClassifier(n_estimators=50, random_state=42)
            model.fit(X, y)
            
            # اختبار النموذج
            test_val = 624
            pred = model.predict([[test_val]])[0]
            print(f"🧪 اختبار النموذج - CO2: {test_val} → {pred}")
            
            joblib.dump(model, 'co2_model.joblib')
            print("✅ النموذج تم تدريبه وحفظه!")
            return model
            
        except Exception as e:
            print(f"❌ خطأ في التدريب: {e}")
    
    return None

# تحميل أو إنشاء النموذج
model = None
try:
    model = joblib.load('co2_model.joblib')
    print("✅ النموذج المحفوظ تم تحميله!")
except:
    print("🔄 جاري محاولة تدريب نموذج جديد...")
    model = train_model_if_possible()

@app.route('/predict', methods=['POST'])
def predict():
    data = request.json
    co2_value = float(data['CO2'])
    
    # استخدام النموذج إذا كان متاحاً، وإلا استخدام التصنيف اليدوي
    if model is not None:
        try:
            prediction = model.predict([[co2_value]])[0]
            method = "AI Model"
        except:
            prediction = classify_co2_manual(co2_value)
            method = "Manual (Fallback)"
    else:
        prediction = classify_co2_manual(co2_value)
        method = "Manual"
    
    return jsonify({
        "input_co2": co2_value,
        "prediction": prediction,
        "method": method,
        "status": "success"
    })

@app.route('/test', methods=['GET'])
def test():
    """صفحة اختبار"""
    test_values = [500, 624, 800, 1000]
    results = []
    
    for val in test_values:
        if model is not None:
            pred = model.predict([[val]])[0]
            method = "AI Model"
        else:
            pred = classify_co2_manual(val)
            method = "Manual"
        
        results.append({
            "co2": val,
            "prediction": pred,
            "method": method
        })
    
    return jsonify({"test_results": results})

@app.route('/info', methods=['GET'])
def info():
    """معلومات عن النظام"""
    return jsonify({
        "model_loaded": model is not None,
        "classification_method": "AI Model" if model else "Manual",
        "manual_thresholds": {
            "Safe": "CO2 < 600",
            "Moderate": "600 ≤ CO2 < 900", 
            "Heavy": "CO2 ≥ 900"
        }
    })

if __name__ == '__main__':
    print("🚀 الخادم يعمل على http://localhost:5000")
    print("📊 حالة النموذج:", "محمل" if model else "يدوي")
    app.run(debug=True)