#include <WiFi.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>

// إعدادات الواي فاي
const char* ssid = "Rana";
const char* password = "RANA2008";

// إعدادات الخادم
const char* serverURL = "http://10.185.137.215:5000/predict";

// حساس MQ135 على pin 34
const int MQ135_PIN = 34;

void setup() {
  Serial.begin(115200);
  connectToWiFi();
  pinMode(MQ135_PIN, INPUT);
  Serial.println("🚀 النظام جاهز!");
}

void loop() {
  int mq135Value = analogRead(MQ135_PIN);
  int co2Estimate = map(mq135Value, 0, 4095, 300, 5000);
  
  Serial.print("🔢 MQ135 Raw Value: ");
  Serial.println(mq135Value);
  Serial.print("🌫️ CO2 Estimate: ");
  Serial.print(co2Estimate);
  Serial.println(" ppm");
  
  // التصنيف المحلي المضمون
  String localPrediction = classifyCO2(co2Estimate);
  Serial.print("🎯 التوقع المحلي: ");
  Serial.println(localPrediction);
  
  // إرسال للخادم
  sendToServer(co2Estimate);
  
  delay(10000);
}

String classifyCO2(int co2Value) {
  if (co2Value < 600) return "Safe";
  else if (co2Value < 900) return "Moderate";
  else return "Heavy";
}

void connectToWiFi() {
  Serial.print("📡 جاري الاتصال...");
  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(1000);
    Serial.print(".");
  }
  Serial.println("\n✅ متصل!");
  Serial.print("📶 IP: ");
  Serial.println(WiFi.localIP());
}

void sendToServer(int co2Value) {
  if (WiFi.status() == WL_CONNECTED) {
    HTTPClient http;
    http.begin(serverURL);
    http.addHeader("Content-Type", "application/json");
    
    String jsonData = "{\"CO2\":" + String(co2Value) + "}";
    
    Serial.println("📤 جاري الإرسال...");
    Serial.println("📦 JSON: " + jsonData);
    
    int httpResponseCode = http.POST(jsonData);
    
    if (httpResponseCode > 0) {
      String response = http.getString();
      Serial.println("📨 استجابة الخادم:");
      Serial.println(response);
    } else {
      Serial.print("❌ خطأ: ");
      Serial.println(httpResponseCode);
    }
    http.end();
  } else {
    Serial.println("❌ غير متصل بالواي فاي");
  }
}