import requests

# جرب قيمة واحدة أولاً
try:
    response = requests.post("http://localhost:8000/predict", json={"CO2": 140})
    print("Status:", response.status_code)
    print("Response:", response.json())
except Exception as e:
    print("Error:", e)